﻿namespace ShootR
{
    public enum Movement
    {
        RotatingLeft,
        RotatingRight,
        Forward,
        Backward
    }
}