﻿namespace ShootR
{
    public class BulletCompressionContract
    {
        // NOTE: CollidableCompressionContrat base class takes up the first X integer array arguments
        public short DamageDealt = 15;
    }
}