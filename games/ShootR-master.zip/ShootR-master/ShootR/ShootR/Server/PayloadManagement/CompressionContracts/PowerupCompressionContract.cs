﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShootR
{
    public class PowerupCompressionContract
    {
        public short PositionX = 0;
        public short PositionY = 1;
        public short ID = 2;
        public short Disposed = 3;
        public short Type = 4;
    }
}