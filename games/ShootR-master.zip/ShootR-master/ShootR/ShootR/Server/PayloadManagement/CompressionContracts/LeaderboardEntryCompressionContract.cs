﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShootR
{
    public class LeaderboardEntryCompressionContract
    {
        public short Name = 0;
        public short Photo = 1;
        public short ID = 2;
        public short Level = 3;
        public short Kills = 4;
        public short Deaths = 5;
        /*public short DamageDealt = 5;
        public short DamageTaken = 6;
        public short KillDeathRatio = 7;*/        
    }
}