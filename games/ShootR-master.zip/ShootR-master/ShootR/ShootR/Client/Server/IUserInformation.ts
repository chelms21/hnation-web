module ShootR.Server {

    export interface IUserInformation {
        Name: string;
        Photo: string;
        RegistrationID: string;
    }

}