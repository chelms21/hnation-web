declare module ShootR {

    export interface IMoving {
        Forward: boolean;
        Backward: boolean;
        RotatingLeft: boolean;
        RotatingRight: boolean;
    }

}